## 0.1.0 - First Version
* Package created
* Event Listener added
## 0.2.0 - First Release
* Released
## 0.2.1 - Feature Add
* Added click event options
* Adjacent line toggle bug fixed
