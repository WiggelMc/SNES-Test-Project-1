module.exports = {
	extends: '@semantic-release/apm-config',
}
