/** @babel */

export const a = 1
