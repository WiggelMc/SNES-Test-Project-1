# find-trailing-whitespace package

Atom package that finds and selects trailing whitespace.

I don't like the Whitespace package that strips all trailing whitespace without telling about it, i want control. That's why I created this package that finds and selects the next trailing whitespace in the buffer when pressing <kbd>shift-alt-w</kbd>

