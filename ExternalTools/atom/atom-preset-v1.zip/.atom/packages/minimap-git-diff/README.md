# minimap-git-diff package

A minimap binding for the Atom git-diff package.

![Minimap Git Diff Screenshot](https://github.com/atom-minimap/minimap-git-diff/blob/master/screenshot.png?raw=true)

You will need the [Minimap package](https://github.com/fundon/atom-minimap) installed to use this package.
