# Good News :tada:

We have gained access to the original minimap. :tada:

"minimap-plus" forwards to the original "minimap" that now includes all the improvements from "minimap-plus"
